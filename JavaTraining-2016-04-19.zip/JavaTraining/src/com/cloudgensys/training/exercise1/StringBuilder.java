package com.cloudgensys.training.exercise1;

public class StringBuilder {
	public static void main(String a[])
	{
		String s = "HI";
		for(int i=0;i<=100;i++)
		{
			s=s+ " "+i;
		}
		System.out.println(s);
	}

}
