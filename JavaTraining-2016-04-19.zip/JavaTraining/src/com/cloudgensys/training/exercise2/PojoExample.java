package com.cloudgensys.training.exercise2;

public class PojoExample {
	
	private static int ID;
	private String empName;
	private float empSalary;
	private boolean status;
	
	public static int getID() {
		return ID;
	}
	public static void setID(int id) {
		PojoExample.ID = id;
	}
			
}
